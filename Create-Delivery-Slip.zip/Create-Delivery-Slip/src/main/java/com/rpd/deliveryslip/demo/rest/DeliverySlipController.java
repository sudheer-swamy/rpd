package com.rpd.deliveryslip.demo.rest;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rpd.deliveryslip.demo.entity.DeliverySlip;
import com.rpd.deliveryslip.demo.entity.Response;
import com.rpd.deliveryslip.demo.service.DeliverySlipService;

@RestController
@RequestMapping("/api")
public class DeliverySlipController {
    
	@Autowired
    private DeliverySlipService deliverySlipService;

    @GetMapping("/list-slips")
    public List<DeliverySlip> getDeliverySlips() {
    	
        System.out.println("List of delivery slips REST API is invoked");
        return deliverySlipService.getDeliverySlips();
    }
    
    
    @PostMapping("/create-slips")
    public ResponseEntity<DeliverySlip> createDeliverySlip(@RequestBody  DeliverySlip theDeliverySlip)
    {
		
		
        deliverySlipService.createDeliverySlip(theDeliverySlip);
        
        System.out.println("create delivery slip REST API is invoked");
		
		return new ResponseEntity<DeliverySlip>(HttpStatus.OK);
    }

}
