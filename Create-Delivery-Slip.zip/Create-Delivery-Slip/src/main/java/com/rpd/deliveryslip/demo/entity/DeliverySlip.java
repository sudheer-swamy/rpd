package com.rpd.deliveryslip.demo.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.sun.istack.NotNull;

import lombok.ToString;

@Entity
@Table(name = "delivery_slip")
public class DeliverySlip {
	
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Long barcodeId;
    
    private String unitsType;
     
    @NotEmpty
    @Pattern(regexp = "^[A-Z0-9]{13}",message = "limit 13 digits 13 chars only")
    @Size(min=0, max =9)
    @Column(unique = true)
    private String barcode;
    
    @NotNull
    private int quantity;
    
    @NotEmpty
    private long salesMan;
    
    @OneToMany(mappedBy = "delivery_slip",fetch = FetchType.LAZY)
	private List<Barcode> barcodes;
   
    //default constructor
    
    public DeliverySlip() {
    	
    }
    
    //constructor with fields
    
    public DeliverySlip(Long barcodeId, String unitsType,
			@NotEmpty @Pattern(regexp = "^[A-Z0-9]{13}", message = "limit 13 digits 13 chars only") @Size(min = 0, max = 12) String barcode,
			int quantity, @NotEmpty long salesMan) {
		super();
		this.barcodeId = barcodeId;
		this.unitsType = unitsType;
		this.barcode = barcode;
		this.quantity = quantity;
		this.salesMan = salesMan;
	}
    
    
    
  //getters and setters

	public Long getBarcodeId() {
		return barcodeId;
	}



	public void setBarcodeId(Long barcodeId) {
		this.barcodeId = barcodeId;
	}


	public String getUnitsType() {
		return unitsType;
	}


	public void setUnitsType(String unitsType) {
		this.unitsType = unitsType;
	}


	public String getBarcode() {
		return barcode;
	}


	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public long getSalesMan() {
		return salesMan;
	}


	public void setSalesMan(long salesMan) {
		this.salesMan = salesMan;
	}

	@Override
	public String toString() {
		return "DeliverySlip [barcodeId=" + barcodeId + ", unitsType=" + unitsType + ", barcode=" + barcode
				+ ", quantity=" + quantity + ", salesMan=" + salesMan + ", barcodes=" + barcodes + "]";
	}
	
	


}
