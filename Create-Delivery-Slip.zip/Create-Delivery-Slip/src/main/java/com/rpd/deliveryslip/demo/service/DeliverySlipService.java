package com.rpd.deliveryslip.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rpd.deliveryslip.demo.dao.DeliverySlipRepository;
import com.rpd.deliveryslip.demo.entity.DeliverySlip;


@Service
public class DeliverySlipService {
    
	@Autowired
    private DeliverySlipRepository deliverySlipRepository;

    public List<DeliverySlip> getDeliverySlips(){
    	
    	List<DeliverySlip> deliverySlips = deliverySlipRepository.findAll();
        
    	System.out.println("Getting data from DB : "+deliverySlips);
       
		return deliverySlips;
        
    }
   
    public  DeliverySlip createDeliverySlip(DeliverySlip theDeliverySlip)
    {
        return deliverySlipRepository.save(theDeliverySlip);
    }
    
   
}
