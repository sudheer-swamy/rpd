package com.rpd.deliveryslip.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreateDeliverySlipApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreateDeliverySlipApplication.class, args);
	}

}
