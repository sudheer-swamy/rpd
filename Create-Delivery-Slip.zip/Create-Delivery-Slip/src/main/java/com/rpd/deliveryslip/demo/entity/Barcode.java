package com.rpd.deliveryslip.demo.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "barcode")
public class Barcode {
	
	//fields
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long barcodId;

	private String barcode;

	private String itemDesc;

	private int quantity;

	private Long mrp;

	private Long promoDisc;

	private Long netAmount;

	private Long salesMan;

	private LocalDateTime createdDate;

 	@ManyToOne
	private DeliverySlip delivery_slip;
 	
 	//getters and setters

	public Long getBarcodId() {
		return barcodId;
	}

	public void setBarcodId(Long barcodId) {
		this.barcodId = barcodId;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Long getMrp() {
		return mrp;
	}

	public void setMrp(Long mrp) {
		this.mrp = mrp;
	}

	public Long getPromoDisc() {
		return promoDisc;
	}

	public void setPromoDisc(Long promoDisc) {
		this.promoDisc = promoDisc;
	}

	public Long getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(Long netAmount) {
		this.netAmount = netAmount;
	}

	public Long getSalesMan() {
		return salesMan;
	}

	public void setSalesMan(Long salesMan) {
		this.salesMan = salesMan;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}
 	
 	 	
 	
}
