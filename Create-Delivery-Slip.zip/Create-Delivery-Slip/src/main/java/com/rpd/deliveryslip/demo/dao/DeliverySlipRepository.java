package com.rpd.deliveryslip.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rpd.deliveryslip.demo.entity.DeliverySlip;

public interface DeliverySlipRepository  extends JpaRepository<DeliverySlip, Long> {

}
