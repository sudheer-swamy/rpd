package com.rpd.deliveryslip.demo.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rpd.deliveryslip.demo.entity.DeliverySlip;
import com.rpd.deliveryslip.demo.service.DeliverySlipService;


@WebMvcTest(DeliverySlipController.class)
@WebAppConfiguration
public class DeliverySlipControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@MockBean
	private DeliverySlipService deliverySlipRepo;
	
	
	@Test
	public void testListDeliverySlips() throws Exception {
		
		List<DeliverySlip> listDeliverySlips = new ArrayList<>();
		listDeliverySlips.add(new DeliverySlip(1L, "Kgs", "AP12D3429844", 2, 5218L));
		listDeliverySlips.add(new DeliverySlip(2L, "ML", "TS83D3429866", 1, 5216L));
		listDeliverySlips.add(new DeliverySlip(1L, "Pieces", "TS83D3429955", 4, 5234L));
		listDeliverySlips.add(new DeliverySlip(1L, "Kgs", "AP12D3429521", 1, 5248L));
		listDeliverySlips.add(new DeliverySlip(1L, "Ml", "AP12D3429396", 5, 5274L));
		
		
		
		Mockito.when(deliverySlipRepo.getDeliverySlips()).thenReturn(listDeliverySlips);
		
		String url ="/api/list-slips";
		
		MvcResult mvcResult = mockMvc.perform(get(url)).andExpect(status().isOk()).andReturn();
		
		String actualJsonResponse = mvcResult.getResponse().getContentAsString();
		System.out.println(actualJsonResponse);
		
		String expectedJsonResponse = objectMapper.writeValueAsString(listDeliverySlips);
		
		assertThat(actualJsonResponse).isEqualToIgnoringWhitespace(expectedJsonResponse);
		
	}
	
	@Test
	public void testCreateDeliverySlip() throws JsonProcessingException, Exception {
		DeliverySlip newDeliverySlip = new DeliverySlip(1L, "Kgs", "AP12D3429844", 2, 5218L);
		DeliverySlip savedDeliverySlip = new DeliverySlip(1L, "Kgs", "AP12D3429844", 2, 5218L);
		
		Mockito.when(deliverySlipRepo.createDeliverySlip(newDeliverySlip)).thenReturn(savedDeliverySlip);
		
		String url = "/api/create-slips";
		
		MvcResult result = mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(objectMapper.writeValueAsString(savedDeliverySlip)))
                .andExpect(status().isOk()).andReturn();
		
	   assertThat(result).isNotNull();    
		
       //String userJson = result.getResponse().getContentAsString();
       //assertThat(userJson).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(savedDeliverySlip));

		
		//Assertions.assertEquals(savedDeliverySlip, result.getResponse());
		
	}
	
//	@Test
//    public void addEmployee() throws Exception {
// 
//		DeliverySlip newDeliverySlip = new DeliverySlip(1L, "Kgs", "AP12D3429844", 2, 5218L);
//		
//        Mockito.when(deliverySlipRepo.createDeliverySlip(Mockito.any(DeliverySlip.class))).thenReturn(newDeliverySlip);
//
////        mockMvc.perform(MockMvcRequestBuilders.post("/api/create-slips")
////                .content(asJsonString(newDeliverySlip))
////                .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
////                .andExpect(status().isOk())
////                .andExpect(content().contentType("application/json;charset=UTF-8"));
//        
//
//        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/api/create-slips")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(objectMapper.writeValueAsString(newDeliverySlip).getBytes(StandardCharsets.UTF_8))
//                .accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
//                .andReturn();
//
//        assertThat(result).isNotNull();
//        String userJson = result.getResponse().getContentAsString();
//       // assertThat(userJson).isNotEmpty();
//        assertThat(userJson).isEqualToIgnoringWhitespace(objectMapper.writeValueAsString(newDeliverySlip));
//  }

	
	public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
	

}
