package com.rpd.deliveryslip.demo.repo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.rpd.deliveryslip.demo.dao.DeliverySlipRepository;
import com.rpd.deliveryslip.demo.entity.DeliverySlip;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@TestMethodOrder(OrderAnnotation.class)
public class DeliverySlipRepoTest {
	
	
	@Autowired
	DeliverySlipRepository deliverySlipRepo;
	
	@Test
	@Rollback(false)
	@Order(1)
	@DisplayName("Delivery Slip Creation")
	public void createDeliverySlipTest() {
		
		DeliverySlip ds = new DeliverySlip();
		ds.setBarcodeId(2L);		
		ds.setUnitsType("Pieces");
		ds.setBarcode("DF34T52952798");
		ds.setQuantity(2);
		ds.setSalesMan(1429L);
		DeliverySlip createSlip = deliverySlipRepo.save(ds);
		
		Assertions.assertNotNull(createSlip);
		
	}
	
	
	
	@Test
	@Order(3)
	@DisplayName("Test by BarcodeId Exists ")
	public void tesyByBarcodeIdExists() {
		
      Long id = 1005L;
      
      assertThat(deliverySlipRepo.findById(id).isPresent());
     
	}
	
	@Test
	@Order(4)
	@DisplayName("Test by BarcodeId Not Exists ")
	public void tesyByBarcodeIdNotExists() {
		
      Long id = 1008L;
      
      assertThat(deliverySlipRepo.findById(id).isEmpty());
     
    
	}

	
	
	@Test
	@DisplayName("List Of Delivery Slips")
	@Order(2)
	public void testListSlips()
	{
		
		List<DeliverySlip> slips = deliverySlipRepo.findAll();
		
		for(DeliverySlip deliverySlip : slips)
		{
			System.out.println(deliverySlip);
		}
		
		assertThat(slips).size().isGreaterThan(0);
		//assertThat(slips.size()).isGreaterThanOrEqualTo(1);
		
		}
	
	

}
