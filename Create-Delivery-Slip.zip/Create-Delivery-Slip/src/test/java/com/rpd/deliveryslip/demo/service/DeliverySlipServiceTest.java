package com.rpd.deliveryslip.demo.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.rpd.deliveryslip.demo.dao.DeliverySlipRepository;
import com.rpd.deliveryslip.demo.entity.DeliverySlip;


@ExtendWith(SpringExtension.class)
@SpringBootTest
class DeliverySlipServiceTest {
	
	
		@Autowired
		private DeliverySlipService deliverySlipService;

		@MockBean
		private DeliverySlipRepository deliverySlipRepository;

		@Test
		@Order(2)
		@DisplayName("List Of Delivery Slips")
		public void getDeliverySlipsTest() {

			when(deliverySlipRepository.findAll()).thenReturn(Stream
					.of(new DeliverySlip(5L,"ML","AP12D3424822",1,4245L),
							new DeliverySlip(10L,"Pieces","TS12D3424942",2,4248L)).collect(Collectors.toList()));

			assertEquals(2, deliverySlipService.getDeliverySlips().size());
			

		}

		@Test
		@Order(1)
		@DisplayName("Delivery Slip Creation")
		public void createDeliverySlip() {

			DeliverySlip deliverySlip = new DeliverySlip(12L,"Kgs","AP12D3424944",2,5245L);
			//DeliverySlip deliverySlip1 = new DeliverySlip(12L,"Kgs","AP12D3424944",2,5245L);
			when(deliverySlipRepository.save(deliverySlip)).thenReturn(deliverySlip);
			assertEquals(deliverySlip, deliverySlipService.createDeliverySlip(deliverySlip));
		}
        
		@Test
		@Order(3)
		@DisplayName("Check Delivery Slips Exists or not")
		public void CheckDeliverySlips_Db() {
		
		DeliverySlip ds = new DeliverySlip();
		ds.setBarcodeId(1005L);		
		ds.setUnitsType("Pieces");
		ds.setBarcode("DF34T52952799");
		ds.setQuantity(2);
		ds.setSalesMan(1429);
		List<DeliverySlip> listDeliverySlips = new ArrayList<>();
		listDeliverySlips.add(ds);
		
		
		 when(deliverySlipRepository.findAll()).thenReturn(listDeliverySlips);

	        List<DeliverySlip> fetchedlips = deliverySlipService.getDeliverySlips();
	        assertThat(fetchedlips.size()).isGreaterThan(0);
	        assertEquals(listDeliverySlips, deliverySlipRepository.findAll());
	        Assertions.assertNotNull(listDeliverySlips);
		
		}

	}


	
	


 
